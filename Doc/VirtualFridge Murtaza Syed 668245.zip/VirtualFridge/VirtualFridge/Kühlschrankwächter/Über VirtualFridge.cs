﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kühlschrankwächter
{
    public partial class Über_VirtualFridge : Form
    {
        public Über_VirtualFridge()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void gggg_Click(object sender, EventArgs e)
        {

        }
    }
}
